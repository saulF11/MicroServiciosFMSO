# Trabajador API (REST + GraphQL + MongoDB)

API que expone el recurso **Trabajador** simultáneamente por **REST** y **GraphQL**, usando un único servidor Node.js/Express y MongoDB como base de datos, todo orquestado con Docker.

## Estructura del proyecto

```
trabajador-api/
├── server.js
├── package.json
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── .gitignore
├── .env.example
└── src/
    ├── config/
    │   └── db.js
    ├── models/
    │   └── Trabajador.js
    ├── controllers/
    │   └── trabajador.controller.js
    ├── routes/
    │   └── trabajador.routes.js
    └── graphql/
        ├── typeDefs.js
        └── resolvers.js
```

## Modelo Trabajador

| Campo         | Tipo   | Notas                |
|---------------|--------|-----------------------|
| nombre        | String | requerido             |
| apellido      | String | requerido             |
| cedula        | String | requerido, único      |
| cargo         | String | requerido             |
| departamento  | String | requerido             |
| fechaIngreso  | Date   | requerido              |

## Cómo levantar el proyecto (Docker, recomendado)

Requisitos: Docker y Docker Compose instalados.

```bash
docker compose up --build
```

Esto levanta dos contenedores en la misma red interna (`trabajador_net`):

- **app**: la API Node.js, expuesta en `http://localhost:4000`
- **mongo**: MongoDB, expuesto en `localhost:27017` (para inspección con Compass/MongoDB shell)

La app se conecta a Mongo usando el nombre del servicio como host: `mongodb://mongo:27017/trabajadores`.

Para detener y eliminar los contenedores:

```bash
docker compose down
```

Para borrar también los datos persistidos de Mongo:

```bash
docker compose down -v
```

## Cómo correr en local sin Docker (opcional)

1. Instalar dependencias:
   ```bash
   npm install
   ```
2. Copiar `.env.example` a `.env` y ajustar si es necesario:
   ```bash
   cp .env.example .env
   ```
3. Tener un MongoDB corriendo en `localhost:27017` (o cambiar `MONGO_URI`).
4. Levantar el servidor:
   ```bash
   npm run dev
   ```

## Endpoints REST

Base URL: `http://localhost:4000/trabajador`

### Obtener todos
```
GET /trabajador
```

### Obtener uno por id
```
GET /trabajador/:id
```

### Crear
```
POST /trabajador
Content-Type: application/json

{
  "nombre": "Juan",
  "apellido": "Perez",
  "cedula": "12345678",
  "cargo": "Analista de Sistemas",
  "departamento": "Tecnologia",
  "fechaIngreso": "2024-03-15"
}
```

### Actualizar
```
PUT /trabajador/:id
Content-Type: application/json

{
  "cargo": "Analista Senior"
}
```

### Eliminar
```
DELETE /trabajador/:id
```

## GraphQL

Endpoint: `http://localhost:4000/graphql`
(Se puede probar directo en el navegador, Apollo abre un explorador interactivo, o usando Postman/Insomnia.)

### Query: obtener todos

```graphql
query {
  obtenerTrabajadores {
    id
    nombre
    apellido
    cedula
    cargo
    departamento
    fechaIngreso
  }
}
```

### Query: obtener uno

```graphql
query {
  obtenerTrabajador(id: "665f1c2e5b3d4a0012ab34cd") {
    id
    nombre
    apellido
  }
}
```

### Mutation: crear

```graphql
mutation {
  crearTrabajador(
    nombre: "Maria"
    apellido: "Gonzalez"
    cedula: "87654321"
    cargo: "Contadora"
    departamento: "Finanzas"
    fechaIngreso: "2023-01-10"
  ) {
    id
    nombre
    apellido
  }
}
```

### Mutation: actualizar

```graphql
mutation {
  actualizarTrabajador(
    id: "665f1c2e5b3d4a0012ab34cd"
    cargo: "Contadora Senior"
  ) {
    id
    cargo
  }
}
```

### Mutation: eliminar

```graphql
mutation {
  eliminarTrabajador(id: "665f1c2e5b3d4a0012ab34cd") {
    id
    nombre
    apellido
  }
}
```

## Notas técnicas

- El campo `cedula` tiene un índice único a nivel de MongoDB (`unique: true`); tanto REST como GraphQL devuelven un error controlado (409 en REST, excepción en GraphQL) si se intenta duplicar.
- REST y GraphQL comparten el mismo modelo de Mongoose (`src/models/Trabajador.js`), evitando duplicar lógica de acceso a datos.
- `docker-compose.yml` define una red interna (`trabajador_net`) para que el contenedor `app` resuelva al contenedor `mongo` por nombre de servicio, sin depender de IPs fijas.
